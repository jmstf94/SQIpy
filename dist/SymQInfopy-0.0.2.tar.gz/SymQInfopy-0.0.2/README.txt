This is a package for Symbolic Algebraic calculations in Quantum Information Theory
built on top of Sympy.
